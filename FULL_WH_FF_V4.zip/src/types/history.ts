export interface WorkHistory {
  date: string;
  entryTime: string;
  requiredTime: string;
  outTime: string;
  actualMs: number;
}
