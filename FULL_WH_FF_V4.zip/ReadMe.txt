Build Instructions

This add-on is built using React and Vite.

To reproduce the build:

Install Node.js (v18 or later)

Run npm install

Run npm run build:firefox

The production-ready extension files will be generated in the dist/ directory.